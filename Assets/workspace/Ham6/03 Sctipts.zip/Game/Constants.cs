public class Constants
{
    public enum PlayerType
    {
        None,
        PlayerA,
        PlayerB,
        PlayerX
    }

    public enum GameType
    {
        SinglePlayer,
        DualPlayer,
        MultiPlayer,
    }
}